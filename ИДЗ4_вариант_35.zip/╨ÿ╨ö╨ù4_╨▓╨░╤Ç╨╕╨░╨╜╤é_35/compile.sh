gcc player.c -o player
gcc server.c -o server
gcc print.c -o print